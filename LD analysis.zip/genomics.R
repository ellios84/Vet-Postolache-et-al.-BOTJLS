# Setting QC tresholds:
# 1. Compute ICR, GCR and MAF through plink
# 2. Return a list where the plink.imiss, plink.lmiss, and plink.freq files are stored
# 3. Return a list where a data.frame object is reported in each slot with 
#   a) the expected number of individuals removed, provided a given ICR threshold
#   b) the expected number of SNPs removed, provided a given GCR threshold
#   c) the expected number of SNPs removed, provided a given MAF threshold  

setClass(Class="genomics", representation(res_plink="list",res_thr="list"))

mind_geno_maf <- function(inputname = NULL, thr = c(0, 0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.1, 0.15, 0.2)) {
  
  plink <- list.files(path=".", pattern="plink2")
  sys <- Sys.info()["sysname"]
  res_plink <- list()
  res_thr <- list()
  
  if(!require(bigsnpr)) install.packages("bigsnpr")
  if(!require(data.table)) install.packages("data.table")
  
  if(length(plink)==0) download_plink2(dir="./", overwrite=FALSE, AVX2 = TRUE, verbose=TRUE)
  if (sys=="Windows") system(paste("./plink2.exe --bfile ", inputname, " --missing --freq", sep = ""))
  if (sys=="Linux") system(paste("./plink2 --bfile ", inputname, " --missing --freq", sep = ""))
  if (sys=="Darwin") system(paste("./plink2 --bfile ", inputname, " --missing --freq", sep = ""))
  
  mind <- fread("./plink2.smiss", header=T, stringsAsFactors=F)
  mind <- as.data.frame(mind)
  res_plink[[1]] <- mind
  perc <- array()
  n <- array()
  for (i in 1:length(thr)) {
    perc[i] <- (length(which(mind$F_MISS >= thr[i]))/nrow(mind))*100
    n[i] <- length(which(mind$F_MISS >= thr[i]))
  }; rm(i)
  mind_thr <- as.data.frame(cbind(thr, perc, n))
  colnames(mind_thr) <- c("Threshold", "%_rm", "#_rm")
  res_thr[[1]] <- mind_thr
  
  geno <- fread("./plink2.vmiss", header=T, stringsAsFactors=F)
  geno <- as.data.frame(geno)
  res_plink[[2]] <- geno
  perc <- array()
  n <- array()
  for (i in 1:length(thr)) {
    perc[i] <- (length(which(geno$F_MISS >= thr[i]))/nrow(geno))*100
    n[i] <- length(which(geno$F_MISS >= thr[i]))
  }; rm(i)
  geno_thr <- as.data.frame(cbind(thr, perc, n))
  colnames(geno_thr) <- c("Threshold", "%_rm", "#_rm")
  res_thr[[2]] <- geno_thr
  
  maf <- fread("./plink2.afreq", header=T, stringsAsFactors=F)
  maf <- as.data.frame(maf)  
  res_plink[[3]] <- maf
  perc <- array()
  n <- array()
  for (i in 1:length(thr)) {
    perc[i] <- (length(which(maf$ALT_FREQS <= thr[i]))/nrow(maf))*100
    n[i] <- length(which(maf$ALT_FREQS <= thr[i]))
  }; rm(i)
  maf_thr <- as.data.frame(cbind(thr, perc, n))
  colnames(maf_thr) <- c("Threshold", "%_rm", "#_rm")
  res_thr[[3]] <- maf_thr
  
  names(res_plink) <- c("mind", "geno", "maf")
  names(res_thr) <- c("mind", "geno", "maf")
  
  return(new("genomics",res_plink=res_plink,res_thr=res_thr))
  
}

# Histograms for individual and marker missingness, as well as minor allele frequencies
# input: an object returned by the 'mind_geno_maf' function

mind_geno_maf_hist <- function(mind_geno_maf_obj = NULL, round = 4) {
  
  sys <- Sys.info()["sysname"]
  
  mind <- mind_geno_maf_obj@res_plink[[1]]  
  mind_range <- round(range(mind$F_MISS), round)
  mind_median <- round(median(mind$F_MISS), round)
  
  geno <- mind_geno_maf_obj@res_plink[[2]]
  geno_range <- round(range(geno$F_MISS), round)
  geno_median <- round(median(geno$F_MISS), round)
  
  maf <- mind_geno_maf_obj@res_plink[[3]]
  maf_range <- round(range(maf$ALT_FREQS), round)
  maf_median <- round(median(maf$ALT_FREQS), round)
  
  if (sys=="Windows") {
    windows()
    op <- par(ask=TRUE)
    hist(mind$F_MISS, main="Individual call rate (ICR)", xlab=expression("Missingness (1"-"ICR)"), sub=paste("Median: ", mind_median, " [", mind_range[1], " - ", mind_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.8)
    hist(geno$F_MISS, main="Genotype call rate (GCR)", xlab=expression("Missingness (1"-"GCR)"), sub=paste("Median: ", geno_median, " [", geno_range[1], " - ", geno_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.9)
    hist(maf$ALT_FREQS, main="Minor allele frequency (MAF)", xlab="MAF", sub=paste("Median: ", maf_median, " [", maf_range[1], " - ", maf_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.8)
    par(op)
  }
  
  if (sys=="Linux") {
    x11()
    op <- par(ask=TRUE)
    hist(mind$F_MISS, main="Individual call rate (ICR)", xlab=expression("Missingness (1"-"ICR)"), sub=paste("Median: ", mind_median, " [", mind_range[1], " - ", mind_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.8)
    hist(geno$F_MISS, main="Genotype call rate (GCR)", xlab=expression("Missingness (1"-"GCR)"), sub=paste("Median: ", geno_median, " [", geno_range[1], " - ", geno_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.9)
    hist(maf$ALT_FREQS, main="Minor allele frequency (MAF)", xlab="MAF", sub=paste("Median: ", maf_median, " [", maf_range[1], " - ", maf_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.8)
    par(op)
  }
  
  if (sys=="Darwin") {
    quartz()
    op <- par(ask=TRUE)
    hist(mind$F_MISS, main="Individual call rate (ICR)", xlab=expression("Missingness (1"-"ICR)"), sub=paste("Median: ", mind_median, " [", mind_range[1], " - ", mind_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.8)
    hist(geno$F_MISS, main="Genotype call rate (GCR)", xlab=expression("Missingness (1"-"GCR)"), sub=paste("Median: ", geno_median, " [", geno_range[1], " - ", geno_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.9)
    hist(maf$ALT_FREQS, main="Minor allele frequency (MAF)", xlab="MAF", sub=paste("Median: ", maf_median, " [", maf_range[1], " - ", maf_range[2], "]", sep=""), las=1, col="gray", cex.sub=0.8)
    par(op)
  }
  
}

# Plot the percentage and number of pruned individuals and loci as a function of a specific call rate and minor allele frequancy
# input: an object returned by the 'mind_geno_maf' function

mind_geno_maf_plot <- function(mind_geno_maf_obj = NULL) {
  
  sys <- Sys.info()["sysname"]
  
  mind <- mind_geno_maf_obj@res_thr[[1]]  
  geno <- mind_geno_maf_obj@res_thr[[2]]
  maf <- mind_geno_maf_obj@res_thr[[3]]
  
  if (sys=="Windows") {
    windows()
    op <- par(ask=TRUE)
    plot(mind$Threshold, mind$`%_rm`, main = "Individual call rate", xlab = "Max. missingness allowed", ylab = "Removed individuals", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(mind$Threshold, mind$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    plot(geno$Threshold, geno$`%_rm`, main = "Genotype call rate", xlab = "Max. missingness allowed", ylab = "Removed markers", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(geno$Threshold, geno$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    plot(maf$Threshold, maf$`%_rm`, main = "Minor allele frequency (MAF)", xlab = "Min. MAF allowed", ylab = "Removed markers", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(maf$Threshold, maf$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    par(op)
  }
  
  if (sys=="Linux") {
    x11()
    op <- par(ask=TRUE)
    plot(mind$Threshold, mind$`%_rm`, main = "Individual call rate", xlab = "Max. missingness allowed", ylab = "Removed individuals", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(mind$Threshold, mind$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    plot(geno$Threshold, geno$`%_rm`, main = "Genotype call rate", xlab = "Max. missingness allowed", ylab = "Removed markers", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(geno$Threshold, geno$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    plot(maf$Threshold, maf$`%_rm`, main = "Minor allele frequency (MAF)", xlab = "Min. MAF allowed", ylab = "Removed markers", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(maf$Threshold, maf$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    par(op)
  }
  
  if (sys=="Darwin") {
    quartz()
    op <- par(ask=TRUE)
    plot(mind$Threshold, mind$`%_rm`, main = "Individual call rate", xlab = "Max. missingness allowed", ylab = "Removed individuals", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(mind$Threshold, mind$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    plot(geno$Threshold, geno$`%_rm`, main = "Genotype call rate", xlab = "Max. missingness allowed", ylab = "Removed markers", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(geno$Threshold, geno$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    plot(maf$Threshold, maf$`%_rm`, main = "Minor allele frequency (MAF)", xlab = "Min. MAF allowed", ylab = "Removed markers", ylim = c(0, 100), t="l", las=1) 
    abline(h=0, lty=3, col="gray")
    abline(v=0, lty=3, col="gray")
    points(maf$Threshold, maf$`#_rm`, t="l", col="red")
    legend("topright", bty="n",legend = c("Percentage", "Number"), lty = 1, col=c("black", "red"), bg = "white")
    box()
    par(op)
  }
  
}