# Quality control (QC) analysis -------------------------------------------

# Sourcing required functions
source("genomics.R")

# Defining QC thresholds
qc_thr <- mind_geno_maf(inputname="Eugenia", thr = seq(0, 0.1, 0.001))
mind_geno_maf_hist(qc_thr)

qc_thr@res_thr
mind_geno_maf_plot(qc_thr)


# Individual call rate
mind <- 0.1
  
# Genotype call rate
geno <- 0.1

# Minor allele frequency
maf <- 0.01

# QC
prefix.in <- "Eugenia"

if(!require(bigsnpr)) install.packages("bigsnpr")

download_plink2(dir = "./",AVX2 = TRUE,overwrite = FALSE,verbose = TRUE)
snp_plinkQC(
  plink.path = "./plink2.exe",
  prefix.in = paste0("./", prefix.in),
  file.type = "--bfile",
  prefix.out = paste0("./", prefix.in, "_qced"),
  maf = maf,
  geno = geno,
  mind = mind,
  hwe = 1e-50,
  autosome.only = FALSE,
  extra.options = "--king-cutoff 0.354", # to screen for duplicate samples 
  verbose = TRUE
)

# DAPC --------------------------------------------------------------------

if(!require(adegenet)) install.packages("adegenet")

# Working dataset for DAPC
system("./plink2.exe --bfile Eugenia_qced --export A --out Eugenia_qced")

# Reading input file for DAPC
dapc_input <- read.PLINK("Eugenia_qced.raw", parallel = FALSE)

# Max K to test in K-means analysis
maxk <- 10

# K-means analysis
grp <- find.clusters(dapc_input, pca.select = "percVar",
                     perc.pca = 99, max.n.clust = maxk, choose.n.clust = TRUE)

# First DAPC to individuate the optimal number of principal components to retain
dapc <- dapc(dapc_input, grp$grp, pca.select = "percVar", perc.pca = 99, n.da = length(grp$size) - 1) 
ascore <- optim.a.score(dapc)

# Performing DAPC again this time based on the first PCA dimension only
dapc <- dapc(dapc_input, grp$grp, n.pca = ascore$best, n.da = length(grp$size) - 1)
print(dapc)
par(mfrow=c(1,2))
scatter(dapc, 1, 1, bg = "white", col = c("red", "blue", "green"), legend = F, cleg = 0.6, solid = 0.4)
scatter(dapc, 2, 2, bg = "white", col = c("red", "blue", "green"), legend = F, cleg = 0.6, solid = 0.4)

# DAPC assignments
dapc_a <- as.data.frame(dapc$posterior)
class(dapc_a)
dapc_a$a <- NA
for (i in 1:nrow(dapc_a)) {
  dapc_a$a[i]<-which(dapc_a[i, 1:3]>0.6)
}
dapc_a$FID <- dapc_input@pop


# Saving genetic clusters as derived from DAPC ----------------------------

download_plink(dir="./", overwrite=FALSE, verbose=TRUE)

c1 <- subset(dapc_a, dapc_a$a==1)
c1 <- data.frame(c1$FID, rownames(c1))
write.table(c1, "c1.txt", col.names = FALSE, row.names = F, sep="\t", quote = FALSE)
system("./plink2.exe --bfile Eugenia_qced --keep c1.txt --make-bed --out Eugenia_qced_c1")
system("./plink.exe --bfile Eugenia_qced_c1 --recode --out Eugenia_qced_c1")

c2 <- subset(dapc_a, dapc_a$a==2)
c2 <- data.frame(c2$FID, rownames(c2))
write.table(c2, "c2.txt", col.names = FALSE, row.names = F, sep="\t", quote = FALSE)
system("./plink2.exe --bfile Eugenia_qced --keep c2.txt --make-bed --out Eugenia_qced_c2")
system("./plink.exe --bfile Eugenia_qced_c2 --recode --out Eugenia_qced_c2")

c3 <- subset(dapc_a, dapc_a$a==3)
c3 <- data.frame(c3$FID, rownames(c3))
write.table(c3, "c3.txt", col.names = FALSE, row.names = F, sep="\t", quote = FALSE)
system("./plink2.exe --bfile Eugenia_qced --keep c3.txt --make-bed --out Eugenia_qced_c3")
system("./plink.exe --bfile Eugenia_qced_c3 --recode --out Eugenia_qced_c3")

# Linkage disequilibrium analysis -----------------------------------------

if(!require(plyr)) install.packages("plyr")
if(!require(genetics)) install.packages("genetics")
if(!require(data.table)) install.packages("data.table")

# Loading the ped/map file corresponding to cluster one
c1ped <- fread("Eugenia_qced_c1.ped")
id <- paste0(c1ped$V1,"_",c1ped$V2)
c1ped <- c1ped[, 7:ncol(c1ped)] 
c1map <- fread("Eugenia_qced_c1.map")
snp.id <- locus(c1map$V2)
c1 <- as.data.frame(matrix(nrow = nrow(c1ped), ncol = ncol(c1ped)/2))
colnames(c1) <- snp.id$name
rownames(c1) <- id
j <- 1
for (i in seq(1, ncol(c1ped), 2)) {
  c1[, j] <- paste(as.data.frame(c1ped)[, i], as.data.frame(c1ped)[, i+1], sep = "/")
  j <- j+1
}; rm(i, j)
c1[which(c1 == "0/0", arr.ind = T)] <- NA
c1 <- makeGenotypes(data = c1, convert = colnames(c1), locus = snp.id)

# Loading the ped/map file corresponding to cluster two
c2ped <- fread("Eugenia_qced_c2.ped")
id <- paste0(c2ped$V1,"_",c2ped$V2)
c2ped <- c2ped[, 7:ncol(c2ped)] 
c2 <- as.data.frame(matrix(nrow = nrow(c2ped), ncol = ncol(c2ped)/2))
colnames(c2) <- snp.id$name
rownames(c2) <- id
j <- 1
for (i in seq(1, ncol(c2ped), 2)) {
  c2[, j] <- paste(as.data.frame(c2ped)[, i], as.data.frame(c2ped)[, i+1], sep = "/")
  j <- j+1
}; rm(i, j)
c2[which(c2 == "0/0", arr.ind = T)] <- NA
c2 <- makeGenotypes(data = c2, convert = colnames(c2), locus = snp.id)

# Loading the ped/map file corresponding to cluster three
c3ped <- fread("Eugenia_qced_c3.ped")
id <- paste0(c3ped$V1,"_",c3ped$V2)
c3ped <- c3ped[, 7:ncol(c3ped)] 
c3 <- as.data.frame(matrix(nrow = nrow(c3ped), ncol = ncol(c3ped)/2))
colnames(c3) <- snp.id$name
rownames(c3) <- id
j <- 1
for (i in seq(1, ncol(c3ped), 2)) {
  c3[, j] <- paste(as.data.frame(c3ped)[, i], as.data.frame(c3ped)[, i+1], sep = "/")
  j <- j+1
}; rm(i, j)
c3[which(c3 == "0/0", arr.ind = T)] <- NA
c3 <- makeGenotypes(data = c3, convert = colnames(c3), locus = snp.id)

# List containing the molecular datasets
g_list <- list()
g_list[[1]] <- c1
g_list[[2]] <- c2
g_list[[3]] <- c3

# Nominal threshold for statistical significance
alpha <- 1*10^-2

# Linkage disequilibrium analysis
for (i in 1:length(g_list)) {
  
  print(paste("Calculating LD in genetic cluster ", i, sep=""))
  
  # LD estimation
  ld <- LD(g_list[[i]])
  t <- which(upper.tri(ld$`P-value`), arr.ind = T)
  ld.p <- data.frame(snp1 = rep(NA, nrow(t)), 
                     snp2 = rep(NA, nrow(t)), 
                     p.value = rep(NA, nrow(t)))
  
  # Pairwise p-values 
  for (w in 1:nrow(t)) {
    ld.p[w, 1] <- rownames(ld$`P-value`)[t[w, 1]]
    ld.p[w, 2] <- colnames(ld$`P-value`)[t[w, 2]]
    ld.p[w, 3] <- ld$`P-value`[t[w, 1], t[w, 2]]
  }; rm(w, t)
  
  # Correction for multiple testing
  ld.p$bonf <- p.adjust(p = ld.p$p.value, method = "bonferroni")
  
  # Significant tests after correction
  # ld.sign <- ld.p[which(ld.p$bonf <= alpha), ][, c(1, 2)]
  ld.sign <- ld.p[which(ld.p$bonf <= alpha), ]
  
  # Sort SNPs as a function of their frequency in pairwise significant tests
  t <- sort(table(c(ld.sign$snp1, ld.sign$snp2)), decreasing = T)
  
  # Initialization of the array that will contain SNPs to remove
  ld.rm <- array()
  
  # Removal of linked SNPs from the dataset
  j <- 1
  while (length(which(ld.p$bonf <= alpha)) != 0) {
    
    # Name of the most frequent SNP to remove from the dataset
    ld.rm[j] <- names(t[1])
    
    # Removal of the most frequent SNP from the dataset
    g_list[[i]] <- g_list[[i]][, -which(names(t[1]) == colnames(g_list[[i]]))]
    
    # Linkage re-estimation among the remaining SNPs
    ld <- LD(g_list[[i]])
    t <- which(upper.tri(ld$`P-value`), arr.ind = T)
    ld.p <- data.frame(snp1 = rep(NA, nrow(t)), 
                       snp2 = rep(NA, nrow(t)), 
                       p.value = rep(NA, nrow(t)))
    
    # Pairwise p-values
    for (w in 1:nrow(t)) {
      ld.p[w, 1] <- rownames(ld$`P-value`)[t[w, 1]]
      ld.p[w, 2] <- colnames(ld$`P-value`)[t[w, 2]]
      ld.p[w, 3] <- ld$`P-value`[t[w, 1], t[w, 2]]
    }; rm(w, t)  
    
    # Correction for multiple testing
    ld.p$bonf <- p.adjust(p = ld.p$p.value, method = "bonferroni")
    
    # Significant tests after correction
    # ld.sign <- ld.p[which(ld.p$bonf <= alpha), ][, c(1, 2)]
    ld.sign <- ld.p[which(ld.p$bonf <= alpha), ]
    
    # Sort SNPs as a function of their frequency in pairwise significant tests
    t <- sort(table(c(ld.sign$snp1, ld.sign$snp2)), decreasing = T)
    
    # Increasing j by 1
    j <- j+1
    
  }; rm(j, t)
  
  ld.rm <- as.data.frame(ld.rm)
  write.table(ld.rm, paste("ldrm_c", i,"_alpha", alpha, ".txt", sep=""), col.names = F, row.names = F, quote = FALSE, sep = "\t")
  write.table(ld.p, paste("leq_c", i,"_alpha", alpha, ".txt", sep=""), col.names = T, row.names = F, quote = FALSE, sep = "\t")
}; rm(i)

# Upload SNPs in linkage from each genetic cluster
ld.rm <- list.files(path = ".", pattern = "ldrm")
print(ld.rm)
for (i in 1:length(ld.rm)) {
  assign(x = paste("ldrm_c", i, sep=""), value = read.table(ld.rm[i], stringsAsFactors = F))
}; rm(i)

# SNPs in linkage that are shared among genetic clusters
ld.rm.shared <- table(c(ldrm_c1[, 1], ldrm_c2[, 1], ldrm_c3[, 1]))
ld.rm.shared <- names(ld.rm.shared[which(ld.rm.shared == 3)])
write.table(ld.rm.shared, paste("ldrm_shared_", alpha, ".txt", sep=""), 
            col.names = F, row.names = F, quote = FALSE, sep = "\t")

# Venn diagram
library(gplots)
venn(list("Cluster 1"=ldrm_c1[, 1], "Cluster 2"=ldrm_c2[, 1], "Cluster 3"=ldrm_c3[, 1]))

# Linkage disequilibrium pruning ------------------------------------------
system("plink.exe --bfile Eugenia_qced --exclude ldrm_shared_0.01.txt --recode --make-bed --out Eugenia_qced_")

prefix.in <- "Eugenia_qced_"
snp_plinkQC(
  plink.path = "./plink2.exe",
  prefix.in = paste0("./", prefix.in),
  file.type = "--bfile",
  prefix.out = paste0("./", prefix.in, "ldpruned"),
  maf = maf,
  geno = geno,
  mind = mind,
  hwe = 1e-50,
  autosome.only = FALSE,
  extra.options = "--king-cutoff 0.354", # to screen for duplicate samples 
  verbose = TRUE
)
