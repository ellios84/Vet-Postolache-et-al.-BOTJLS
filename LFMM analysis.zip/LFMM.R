# LFMM analysis

# Population structure and signals of local adaptation in Eugenia uniflora L. (Myrtaceae), 
# a widely distributed species in the Atlantic Forest

# authors: Vet� NM, Postolache D, Escudero FLG, Vajana E, Burgo Braga R, Salgueiro F,
# Margis R, Vendramin GG, Turchetto-Zolet AC

# significance threshold
alpha <- 0.01

# Prepearing the input file for LFMM analysis
library(LEA)
struct2geno("361SNPs_Structure_Eugenia.str", ploidy=2, FORMAT=1, extra.row=0, extra.col=2)
eugenia.genotype <- read.lfmm('361SNPs_Structure_Eugenia.str.lfmm')
dim(eugenia.genotype)
write.lfmm(output.file="361SNPs_Structure_Eugenia.lfmm", eugenia.genotype)

nbLocus <- dim(eugenia.genotype) [2]
SNP.eugenia.seqID <- seq(1:nbLocus)
SNP.eugenia.ID <- as.matrix(read.table("361snps_list.csv", quote="\"", comment.char=""))
nbIndiv <- dim(eugenia.genotype) [1]

# Evaluating the number of missing data: 
miss.dataeugenia <- apply(eugenia.genotype, 2, FUN=function(x) sum(x==9))
nbNA <- sum(miss.dataeugenia)
nbAll <- nbIndiv*nbLocus
nbNA/nbAll

rm (nbAll); rm (nbNA)
rm(miss.dataeugenia)

# Population table
# Number of individuals per population
coordIndiv <- read.delim("Coord_Eugenia_80Indiv_LDpruned.csv", sep=",")
eugenia.pop.ID <- coordIndiv$POP
tmp <- table(eugenia.pop.ID)
sum(tmp)
nbindivPerPop <- as.data.frame(cbind(names(tmp),tmp))
colnames(nbindivPerPop) <- c("POP", "NbIndiv")
nbindivPerPop$NbIndiv <- tmp
rm(tmp)

# Environment table
# We need a matrix n X d, where n=nbIndiv and d=nb environmental variables
syntheticACPVariables <- read.csv("synthetic_6_PCAVariables_ordered.csv", sep=",")
dim(syntheticACPVariables)
colnames(syntheticACPVariables)

library(plyr)
library(dplyr)

syntheticACPVariables=dplyr::left_join(syntheticACPVariables, nbindivPerPop, by=c("POPID"="POP"))

Temp1 = NULL; Temp2=NULL; Temp3= NULL
for (i in 1:4){ 
  Temp1 = c(Temp1, rep(syntheticACPVariables[i,2], syntheticACPVariables[i,11]) )  #PC1_Temp1
  Temp2 = c(Temp2, rep(syntheticACPVariables[i,3], syntheticACPVariables[i,11]) )  #PC3_Temp3
  Temp3 = c(Temp3, rep(syntheticACPVariables[i,4], syntheticACPVariables[i,11]) )  #PC3_Temp3
}

Precip1 = NULL; Precip2= NULL; Precip3 = NULL
for (i in 1:4){ 
  Precip1 = c(Precip1, rep(syntheticACPVariables[i,5], syntheticACPVariables[i,11]) ) #PC1_Precip1 
  Precip2 = c(Precip2, rep(syntheticACPVariables[i,6], syntheticACPVariables[i,11]) ) #PC1_Precip1 
  Precip3 = c(Precip3, rep(syntheticACPVariables[i,7], syntheticACPVariables[i,11]) ) #PC2_Precip3 
}
rm(i)

eugenia.env= cbind(Temp1, Temp2, Temp3, Precip1, Precip2, Precip3)
colnames(eugenia.env)=c("Temp1", "Temp2", "Temp3", "Precip1", "Precip2", "Precip3")

rm(list=ls(pattern="Temp"))
rm(list=ls(pattern="Precip"))
rm(nbindivPerPop)
rm(syntheticACPVariables)

# Estimation of population structure to identify the best K(s) for properly 
# imputing missing data
# sNMF analysis
postscript("snmf-ce-361snps-10runs-20rep.eps", width = 7, height = 5)
par(mfrow=c(2, 5), mar=c(2, 2, 0, 0), oma=c(5, 4, 5, 0))

# Ten independent sNMF runs from K=1 to K=10, each with 20 repetitions 
# i.e., a total of 200 runs per K is performed
eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100,
                            project="new")
  
# Since the program was called with the entropy option, we can plot the values 
# of the cross-entropy criterion for each K. 
# The value for which the function plateaus or increases is our estimate of K.
  
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
  
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", 
ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
axis(side = 2, at = seq(0, 0.5, 0.1), labels = seq(0, 0.5, 0.1), las=1)
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")
axis(side = 2, at = seq(0, 0.5, 0.1), labels = seq(0, 0.5, 0.1), las=1)
axis(side = 1, at = 1:5, labels = 1:5, las=1)

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")
axis(side = 1, at = 1:5, labels = 1:5, las=1)

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")
axis(side = 1, at = 1:5, labels = 1:5, las=1)

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")
axis(side = 1, at = 1:5, labels = 1:5, las=1)

eugenia_361_80.snmf <- snmf("361SNPs_Structure_Eugenia.lfmm", K=1:5,
                            ploidy=2, entropy=T, repetitions=20, alpha=100, 
                            project="new")
ce1 <- cross.entropy(eugenia_361_80.snmf, K = 1)
ce2 <- cross.entropy(eugenia_361_80.snmf, K = 2)
ce3 <- cross.entropy(eugenia_361_80.snmf, K = 3)
ce4 <- cross.entropy(eugenia_361_80.snmf, K = 4)
ce5 <- cross.entropy(eugenia_361_80.snmf, K = 5)
ce <- cbind.data.frame(ce1, ce2, ce3, ce4, ce5)
plot(0:5, seq(0, 0.5, 0.1), xaxt="n", yaxt="n", t="n", ylim=c(0.25, 0.5), xlim=c(0, 6))
boxplot(ce, add=T, xaxt="n", yaxt="n")
remove.snmfProject("361SNPs_Structure_Eugenia.snmfProject")
axis(side = 1, at = 1:5, labels = 1:5, las=1)

mtext(text = "Number of ancestral populations", side = 1, line = 1, outer = T, at = 0.5, cex=1.5)
mtext(text = "Cross entropy", side = 2, line = 1, outer = T, at = 0.5, cex=1.5)
dev.off()

# We identified the best Ks by using unlinked SNPs only (i.e, K=3 and K=4)
# Then, we impute missing data in the whole dataset (372 SNPs) by relying on K=3 first
# and then K=4 
require(lfmm)
tmp <- read.lfmm("2021_Eugenia_qced_ldpruned_372snp_80ind.str.lfmm")
dim(tmp)
write.lfmm(output.file = 'eugeniageno_372snp_80ind.lfmm', tmp)

eugenia_372_80.snmf <- snmf("eugeniageno_372snp_80ind.lfmm", K = 3:4,
                            ploidy  = 2,  entropy = T, repetitions=20, alpha  = 100,
                            project = "new")

cross.entropy(eugenia_372_80.snmf, K=3)
best <- which.min(cross.entropy(eugenia_372_80.snmf, K=3))
impute(eugenia_372_80.snmf, input.file='eugeniageno_372snp_80ind.lfmm', 
       method='mode', K=3, run=best) 
eugenia_372_80.imputed <- read.lfmm('eugeniageno_372snp_80ind.lfmm_imputed.lfmm')
unique(as.numeric(eugenia_372_80.imputed))
miss.dataeugeniaimputed <- apply(eugenia_372_80.imputed, 2, FUN = function(x) sum(x == 9))
rm(miss.dataeugeniaimputed)
write.lfmm(eugenia_372_80.imputed, "eugenia_372_80.imputed.lfmm")
lfmm2geno("eugenia_372_80.imputed.lfmm", "eugenia_372_80.imputed.geno")
SNP.eugenia.ID <- as.matrix(read.table("snps_list.csv", quote="\"", comment.char=""))
nbIndiv <- dim(tmp) [1]

library(scales)
library(plyr)

y <- scale(eugenia_372_80.imputed)
x <- scale(eugenia.env)

env.names <- colnames(eugenia.env)
res <- list()
for (i in 1:length(env.names)) {
  
  t <- env.names[i]
  
  # LFMM ridge estimates
  temp_i=lfmm_ridge(Y = y, X = x[,i], K = 3, lambda = 1e-5)
  
  # Estimates are used for computing calibrated significance values and for testing 
  # associations between the response matrix Y and the explanatory matrix X.
  temp_i.p=lfmm::lfmm_test(Y = y, X = x[,i], lfmm = temp_i, calibrate = "gif")
  res_i=data.frame(cbind(SNP.eugenia.ID, 
                         rep(t,nbLocus),
                         temp_i$V, 
                         temp_i.p$B, 
                         temp_i.p$calibrated.pvalue))
  colnames(res_i)=c("Locus", "Env.var", "V1", "V2", "V3", "Bscore", "calibrated.pvalue")
  res_i$Bscore <- varhandle::unfactor(as.matrix(res_i$Bscore))[,1]
  res_i$calibrated.pvalue <- varhandle::unfactor(as.matrix(res_i$calibrated.pvalue))[,1]
  res_i$Bonf <- p.adjust(p = as.numeric(res_i$calibrated.pvalue), method = "bonferroni")
  
  # Reordering results based on p-values
  res_i <- res_i[order(res_i$calibrated.pvalue, decreasing = F), ]
  
  # Significant tests (Bonf. <=alpha) after Bonferroni correction
  t2 <- which(res_i$Bonf <= alpha)
  bonf_i <- res_i[t2, ]
  if (nrow(bonf_i) > 0) {
    write.table(bonf_i, paste("lfmm-outliers-K3-", t, 
                              "-bonf-alpha", alpha, ".txt", sep = ""),
                col.names = T, row.names = F, quote = FALSE, sep = "\t")
  }
  rm(t2)
}; rm(i)

lfmm_k3_prec1 <- read.table("lfmm-outliers-K3-Precip1-bonf-alpha0.01.txt", h=T)
lfmm_k3_prec2 <- read.table("lfmm-outliers-K3-Precip2-bonf-alpha0.01.txt", h=T)
lfmm_k3_prec3 <- read.table("lfmm-outliers-K3-Precip3-bonf-alpha0.01.txt", h=T)
lfmm_k3_temp2 <- read.table("lfmm-outliers-K3-Temp2-bonf-alpha0.01.txt", h=T)
lfmm_k3 <- rbind.data.frame(lfmm_k3_prec1, lfmm_k3_prec2, lfmm_k3_prec3, lfmm_k3_temp2)

# Preparing results for inspection...

library(knitr)
library(kableExtra)
library(dplyr)
knitr::kable(lfmm_k3, row.names = F, caption="LFMM K=3 (Bonf. alpha=0.01)", digits = 5) %>%
  kable_styling("striped", full_width = F, font_size = 10)

write.table(lfmm_k3, "lfmm-k3-outliers.txt", col.names = T, row.names = F, quote = FALSE, sep = "\t")

# LFMM with K=4
best <- which.min(cross.entropy(eugenia_361_80.snmf, K=4))
my.colors <- c("tomato", "lightblue", "yellow", "forestgreen")
par(mfrow=c(1, 1), mar=c(5,4,3,2))
Q.matrix  <-  barchart(eugenia_361_80.snmf,  
                       K=4, run=best, border=NA, space=0,
                       col=my.colors, xlab="Individuals",
                       ylab="Ancestry proportions", main="Ancestry matrix")

# Imputing missing data K=4
best <- which.min(cross.entropy(eugenia_372_80.snmf, K=4))
impute(eugenia_372_80.snmf, input.file='eugeniageno_372snp_80ind.lfmm', 
       method='mode', K=4, run=best)
eugenia_372_80.imputed <- read.lfmm('eugeniageno_372snp_80ind.lfmm_imputed.lfmm')
unique(as.numeric(eugenia_372_80.imputed))
miss.dataeugeniaimputed <- apply(eugenia_372_80.imputed, 2, FUN=function(x) sum(x==9))
rm(miss.dataeugeniaimputed)
write.lfmm(eugenia_372_80.imputed, "eugenia_372_80.imputed.lfmm")
lfmm2geno("eugenia_372_80.imputed.lfmm", "eugenia_372_80.imputed.geno")

SNP.eugenia.ID <- as.matrix(read.table("snps_list.csv", quote="\"", comment.char=""))
nbIndiv=dim(tmp) [1]

y <- scale(eugenia_372_80.imputed)
x <- scale(eugenia.env)

env.names <- colnames(eugenia.env)
res <- list()
for (i in 1:length(env.names)) {
  
  t <- env.names[i]
  
  #lfmm ridge estimates
  temp_i=lfmm_ridge(Y=y, X=x[,i], K=4, lambda=1e-5)
  
  #the estimates are used for computing calibrated significance values and for testing associations   between the response matrix Y and the explanatory variable X.
  temp_i.p=lfmm::lfmm_test(Y=y, X=x[,i], lfmm=temp_i, calibrate="gif")
  res_i=data.frame(cbind(SNP.eugenia.ID, 
                         rep(t,nbLocus),
                         temp_i$V, 
                         temp_i.p$B, 
                         temp_i.p$calibrated.pvalue))
  colnames(res_i)=c("Locus", "Env.var", "V1", "V2", "V3", "V4", "Bscore", "calibrated.pvalue")
  res_i$Bscore <- varhandle::unfactor(as.matrix(res_i$Bscore))[,1]
  res_i$calibrated.pvalue <- varhandle::unfactor(as.matrix(res_i$calibrated.pvalue))[,1]
  res_i$Bonf <- p.adjust(p = as.numeric(res_i$calibrated.pvalue), method = "bonferroni")
  
  # Reordering results based on p-value
  res_i <- res_i[order(res_i$calibrated.pvalue, decreasing = F), ]
  
  # Significant tests (p Bonf. <=alpha) after Bonferroni correction
  t2 <- which(res_i$Bonf <= alpha)
  bonf_i <- res_i[t2, ]
  if (nrow(bonf_i) > 0) {
    write.table(bonf_i, paste("lfmm-outliers-K4-", t, 
                              "-bonf-alpha", alpha, ".txt", sep = ""),
                col.names = T, row.names = F, quote = FALSE, sep = "\t")
  }
  rm(t2)
}; rm(i)

lfmm_k4_prec1 <- read.table("lfmm-outliers-K4-Precip1-bonf-alpha0.01.txt", h=T)
lfmm_k4_prec2 <- read.table("lfmm-outliers-K4-Precip2-bonf-alpha0.01.txt", h=T)
lfmm_k4_prec3 <- read.table("lfmm-outliers-K4-Precip3-bonf-alpha0.01.txt", h=T)
lfmm_k4_temp2 <- read.table("lfmm-outliers-K4-Temp2-bonf-alpha0.01.txt", h=T)
lfmm_k4 <- rbind.data.frame(lfmm_k4_prec1, lfmm_k4_prec2, lfmm_k4_prec3, lfmm_k4_temp2)

# Preparing results for inspection...
knitr::kable(lfmm_k4, row.names = F, caption="LFMM K=4 (Bonf. alpha=0.01)", digits = 5) %>%
  kable_styling("striped", full_width = F, font_size = 10)

write.table(lfmm_k4, "lfmm-k4-outliers.txt", col.names = T, row.names = F, quote = FALSE, sep = "\t")

# Shared outliers
lfmm.outliers <- sort(table(c(unique(lfmm_k3$Locus), unique(lfmm_k4$Locus))), decreasing = T)
lfmm.outliers <- names(lfmm.outliers[which(lfmm.outliers==2)])
print(lfmm.outliers)

lea.outliers <- row.names(read.table("LEA-outliers-bonf-alpha0.01.txt", h=T))
print(lea.outliers)

shared.ouliers <- sort(table(c(lfmm.outliers, lea.outliers)), decreasing = T)
shared.ouliers <- names(shared.ouliers[which(shared.ouliers==2)])
print(shared.ouliers)
