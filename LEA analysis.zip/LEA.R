# LEA analysis

# Population structure and signals of local adaptation in Eugenia uniflora L. (Myrtaceae), 
# a widely distributed species in the Atlantic Forest

# authors: Vet� NM, Postolache D, Escudero FLG, Vajana E, Burgo Braga R, Salgueiro F,
# Margis R, Vendramin GG, Turchetto-Zolet AC

# LEA data conversion
library(LEA)
library(data.table)

struct2geno("2021_Eugenia_qced_ldpruned_372snp_80ind.str", ploidy=2, 
             FORMAT=2, extra.row=0,  extra.col=2)
genotype <- read.geno('2021_Eugenia_qced_ldpruned_372snp_80ind.str.geno')
dim(genotype)

write.geno(output.file='str.geno', genotype)

# LEA
# Choosing the number of clusters
# In LEA, choosing the number of clusters is based on the cross-entropy criterion.
# Using the genotype matrix, the first step is to evaluate population genetic 
# structure. The snmf function provides outputs similar to those of the computer 
# program STRUCTURE. We create an object of class snmf using the snmf function. 
# Here we run the program for all K, the number of ancestral populations, from 1 to 5
# We perform runs for 5 values of K, and choose the value of K for which the 
# cross-entropy curve exhibits a plateau (K = 3) 
obj.snmf <- snmf("str.geno",  K=1:5,  ploidy=2,  entropy=T, repetitions=10, 
                 alpha=100, project="new")

# Plot cross-entropy criterion for all runs in the snmf project
plot(obj.snmf, col="blue",  pch=19,  cex=1.2)

# The next step is to display a barplot for the Q-matrix
# qmatrix object contains the matrix of ancestry coefficients for each individual 
# and for K=3 clusters select the best run for K=3
best <- which.min(cross.entropy(obj.snmf, K=3))
my.colors <- c("tomato", "lightblue", "yellow")
Q.matrix  <-  barchart(obj.snmf,  K=3, run=best, border = NA, space=0, col=my.colors, 
                       xlab="Individuals", ylab="Ancestry proportions", 
                       main="Ancestry matrix")

# Population differentation tests using snmf
p <- snmf.pvalues(obj.snmf, entropy=TRUE, ploidy=2, K=3)
pvalues <- p$pvalues
par(mfrow=c(2,1))
hist(pvalues, col="orange")
plot(-log10(pvalues), pch=19, col="blue", cex=.7)
write.table(pvalues, "LEA_Eugenia_Pvalues 2021.txt", row.names=FALSE, col.names=FALSE)

# Multiple  testing  correction
# Family-wise error rate: we adjust p-values to represent the probability 
# of making one or more Type I errors among the family of hypothesis tests
p$pvalues <- as.data.frame(p$pvalues)
colnames(p$pvalues) <- "pvalues"
rownames(p$pvalues) <- read.table("snps_list.csv", header=FALSE, stringsAsFactors=F)[, 1]

lea_results <- cbind.data.frame(
  "p.value"=p$pvalues,
  "Bonf"=p.adjust(p=p$pvalues[,1], method="bonferroni")
  )
head(as.data.frame(lea_results), 10)

# Nominal significance threshold
alpha <- 0.01

# Significant tests (Bonf<=alpha) after Bonferroni correction
bonf <- lea_results[which(lea_results$Bonf <= alpha), ]
print(bonf)

write.table(bonf, paste("LEA-outliers-bonf-alpha", alpha, ".txt", sep = ""), 
            col.names = T, row.names = T, quote = FALSE, sep = "\t")

library(knitr)
library(kableExtra)
library(dplyr)

knitr::kable(bonf, row.names = T, caption="Bonferroni correction - alpha = 0.01", digits = 5) %>%
  kable_styling("striped", full_width = F, font_size = 10)
